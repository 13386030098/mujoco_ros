copy **forcedimension.rules** to '/etc/udev/rules.d'
